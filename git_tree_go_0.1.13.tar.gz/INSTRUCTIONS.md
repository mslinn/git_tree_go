1) Examine the RSpec unit tests in /mnt/f/work/git/git_tree/spec then
   generate similar tests for the five commands (in the /cmd directory) in this project.
