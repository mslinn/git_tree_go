package internal

// Version is the current version of git-tree-go
const Version = "0.1.13"
